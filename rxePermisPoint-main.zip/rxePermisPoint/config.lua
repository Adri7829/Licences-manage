Config = {
    menuPermisInfo = {
        {jobName = 'police', posMenu = vector3(443.53, -975.0, 30.69)},
    --  {jobName = 'sheriff', posMenu = vector3(2495.495, -425.207, 99.11)}
    },
    permisdecision = false, -- true pour regrouper les 3 permis (voiture, moto, camion) en 1 /////// false pour avoir 3 permis différent (voiture, moto, camion)
    cmdplayer = "permis" -- /permis pour ouvrir le menu voir les points
}